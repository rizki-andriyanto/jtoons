	

			<div id="footer">
				<div class="left">
					<h2><font color="pink">Menerima Orderan Sketsa Wajah</font></h2>
					<p>Hubungi : </p>
					<a class="icon fa-phone">&nbsp;&nbsp;<span class="label">Telp</span></a>
					<a class="icon fa-envelope">&nbsp;&nbsp;<span class="label">SMS</span></a>
					<a class="icon fa-whatsapp">&nbsp;&nbsp;<span class="label">Whatsapp</span></a>085707430141
					<p>Alamat : </p>
					<a class="icon fa-home">&nbsp;&nbsp;<span class="label">Home</span></a>Ds. Dapur Kejambon RT 08 / RW 02
Jombang  Jawa Timur  Indonesia  Kode Pos 61415
					
				</div>
				<div class="right">
					<ul class="contact">
						<!-- <li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li> -->
						
						<li><a href="https://facebook.com/ajiezzahh.ajiezzahh" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="https://www.instagram.com/nur_hajtoon45/" class="icon fa-instagram"><span class="label">Instagram</span></a></li>

						
						<!-- <li><a href="#" class="icon fa-dribbble"><span class="label">Dribbble</span></a></li>
						<li><a href="#" class="icon fa-pinterest"><span class="label">Pinterest</span></a></li>
						<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li> -->
					</ul>
					<ul class="copyright">
						<li>&copy; 2017 <a href="http://dangdingdong.com">Rizki Andriyanto</a></li><li>Design : <a href="http://html5up.net">HTML5UP</a></li>
					</ul>
				</div>
			</div>

		</div>

		<!-- Scripts -->
			<script src="<?php echo base_url() ?>assets-web/js/jquery.min.js"></script>
			<script src="<?php echo base_url() ?>assets-web/js/jquery.poptrox.min.js"></script>
			<script src="<?php echo base_url() ?>assets-web/js/skel.min.js"></script>
			<script src="<?php echo base_url() ?>assets-web/js/skel-viewport.min.js"></script>
			<script src="<?php echo base_url() ?>assets-web/js/util.js"></script>
			
			<script src="<?php echo base_url() ?>assets-web/js/main.js"></script>

	</body>
</html>