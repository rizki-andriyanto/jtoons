<br>

<footer class="container-fluid text-center">
  &copy; 2017 <a href="http://dangdingdong.com">Rizki Andriyanto
</footer>

</body>
</html>
