<link rel="stylesheet" href="<?php echo base_url('assets-web/css/font-awesome.min.css') ?>"/>
<style>
            body{
                padding: 15px;
            }
        </style>
<div class="alert alert-info">
    <strong>Selamat Datang</strong>  di JToon's Art , Klik <a href="#" class="alert-link"><?php echo anchor(site_url('pagination'),' <i class="fa fa-hand-o-right" aria-hidden="true"></i> <strong><i>Nur Hajizah </strong></b><i class="fa fa-hand-o-left" aria-hidden="true"></i>'); ?> Untuk Masuk Sebagai <b>Admin</b></a>.
 </div>

 