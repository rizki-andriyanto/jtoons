<html>
<head>
	<title>Post</title>
	<link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
	<style>
            body{
                padding: 15px;
            }
        </style>
</head>
<body>
	<h2 style="margin-top:0px">Portfolio Detail</h2>
	  
	<?php $post = $_GET['post_id']; ?>

		<!-- Main -->
			<div id="main">

				<!-- One -->
				
					<section id="one">
						<header class="major">
							<!-- <h2><?php echo $post->title ?></h2> -->
						</header>
						<p>
						<!-- <?php echo $post['content'] ?> -->
						</p>
					</section>


			</div>

  		
</body>




